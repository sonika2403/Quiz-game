class Quiz:
    def __init__(self):
        self.questions = [
            #quiz questions that are supposed to be asked
            {
                "question": "What is the capital of France?",
                "options": ["London", "Paris", "Rome", "Berlin"],
                "answer": "Paris"
            },
            {
                "question": "Which planet is known as the Red Planet?",
                "options": ["Venus", "Mars", "Jupiter", "Mercury"],
                "answer": "Mars"
            },
            {
                "question": "Who painted the Mona Lisa?",
                "options": ["Vincent van Gogh", "Leonardo da Vinci", "Pablo Picasso", "Claude Monet"],
                "answer": "Leonardo da Vinci"
            }
        ]
        self.score = 0  # Initialize score

    def display_question(self, q):
        print(f"\nQ{q + 1}: {self.questions[q]['question']}")
        for i, option in enumerate(self.questions[q]['options']):
            print(f"{i + 1}. {option}")

    def check_answer(self, q, user_answer):
        correct_answer = self.questions[q]['answer']
        if user_answer.lower() == correct_answer.lower():
            print("Correct!")
            self.score += 1
        else:
            print(f"Wrong! The correct answer is: {correct_answer}")
    #the input values and checking how many are correct
    def run_quiz(self):
        print("Welcome to the Quiz!")
        for i in range(len(self.questions)):
            self.display_question(i)
            user_input = input("Enter your answer (1-4): ")
            # Input values to check the performance
            while not user_input.isdigit() or int(user_input) not in range(1, 5):
                user_input = input("Invalid input. Please enter a number between 1 and 4: ")
            user_answer = self.questions[i]['options'][int(user_input) - 1]
            self.check_answer(i, user_answer)

        print(f"\nQuiz Complete!\nYour final score is: {self.score}/{len(self.questions)}")


# Running the code
if __name__ == "__main__":
    quiz = Quiz()
    quiz.run_quiz()


